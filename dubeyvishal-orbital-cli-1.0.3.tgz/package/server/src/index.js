import "./config/env.js";
import express from "express";
import { fromNodeHeaders, toNodeHandler } from "better-auth/node";
import cors from "cors";
import { auth } from "./lib/auth.js";
import prisma from "./lib/db.js";
import { ensureDbConnectionOrExit } from "./lib/dbHealth.js";
import { FRONTEND_URL } from "./config/api.js";
import cliRoutes from "./routes/cliRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { apiRequestSafe } from "../../utils/apiClient.js";

const app = express();
const PORT = process.env.PORT || 8080;
const CLIENT_ORIGIN = FRONTEND_URL;

app.use(express.json());

app.use(
  cors({
    origin: CLIENT_ORIGIN,
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true, 
  })
);

app.all("/api/auth/*splat", toNodeHandler(auth));

app.use("/auth", authRoutes);

app.get("/api/me" , async (req, res)=>{
  const session = await auth.api.getSession({
    headers : fromNodeHeaders (req.headers),
  });

  if (session) {
    return res.json(session);
  }

  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json(null);
  }

  const [scheme, credentials] = authHeader.split(" ");
  if (!scheme || !credentials || scheme.toLowerCase() !== "bearer") {
    return res.status(400).json({ error: "Invalid Authorization header" });
  }

  const dbSession = await prisma.session.findUnique({
    where: { token: credentials },
    include: { user: true },
  });

  if (!dbSession) {
    return res.status(401).json(null);
  }

  if (dbSession.expiresAt && dbSession.expiresAt.getTime() <= Date.now()) {
    return res.status(401).json({ error: "Session expired" });
  }

  return res.json({
    user: dbSession.user,
    session: {
      id: dbSession.id,
      expiresAt: dbSession.expiresAt,
    },
  });
});

app.get("/device" , async(req , res)=>{
  const {user_code} = req.query;
  res.redirect(`${CLIENT_ORIGIN}/device?user_code=${user_code}`)
});

app.use("/api/cli", cliRoutes);

app.use(errorHandler);

const start = async () => {
  await ensureDbConnectionOrExit({
    retries: Number(process.env.DB_CONNECT_RETRIES || 10),
    initialDelayMs: Number(process.env.DB_CONNECT_INITIAL_DELAY_MS || 500),
    maxDelayMs: Number(process.env.DB_CONNECT_MAX_DELAY_MS || 5000),
  });

  const server = app.listen(PORT, () => {
    console.log(`Server is running on ${PORT}`);
  });

  const shutdown = async (signal) => {
    try {
      console.log(`\nReceived ${signal}. Shutting down...`);
      server.close(() => {
        process.exitCode = 0;
      });
      await prisma.$disconnect();
    } catch {
      process.exit(1);
    }
  };

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
};

start();

const resolveClientId = async (cliClientId) => {
  const resolved = (cliClientId || "").trim();
  if (resolved.length > 0) return resolved;

  const response = await apiRequestSafe("/auth/github/client-id", {
    method: "GET",
    requireAuth: false,
  });

  const clientId =
    typeof response?.client_id === "string" ? response.client_id.trim() : "";

  return clientId.length > 0 ? clientId : undefined;
};

// inside loginAction
const clientId = await resolveClientId(options.clientId);

if (!clientId) {
  console.error(chalk.red("GitHub OAuth client ID is not available from the server."));
  console.log(
    chalk.gray(
      "Make sure the backend is deployed and configured with GITHUB_CLIENT_ID."
    )
  );
  process.exit(1);
}

// use clientId in authClient.device.code(...)
const { data, error } = await authClient.device.code({
  client_id: clientId,
  scope: "openid profile email",
});